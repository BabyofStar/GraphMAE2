"""Generate report tables and closeout documents from the same frozen JSON."""
from pathlib import Path
import json
import statistics as st
import sys

sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent.parent
DATA=json.loads((ROOT/'tables/unified_results.json').read_text('utf-8'))
FORMAL=json.loads((ROOT/'sources/formal120/analysis_results.json').read_text('utf-8'))
DS=['cora','citeseer','pubmed'];NAMES=dict(cora='Cora',citeseer='Citeseer',pubmed='PubMed')


def mdtable(headers,rows):
    def val(x):return str(x).replace('|','／')
    return '| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+'\n'.join('| '+' | '.join(val(x) for x in row)+' |' for row in rows)


def write(name,text):
    (ROOT/name).write_text(text.strip()+'\n',encoding='utf-8')


def group(batch,d,m):
    return next(g for g in DATA['development_groups'] if g['batch']==batch and g['dataset']==d and g['method']==m)


def diff(d,m,r,b=None):
    return next(c for c in DATA['development_comparisons'] if c['dataset']==d and c['method']==m and c['reference']==r and (b is None or c['method_batch']==b))


def pm(g,ndigits=3):
    return f"{g['mean_percent']:.{ndigits}f}±{g['population_sd_percent']:.{ndigits}f}"


def main():
    f={(g['dataset'],g['method']):g for g in DATA['formal_groups']}
    formal=mdtable(['数据集','B0','B1','B2','B3','B2−B0，百分点'],[
        [NAMES[d]]+[pm(f[d,m],2) for m in ['B0','B1','B2','B3']]+[f"{DATA['formal_primary'][i]['mean_delta_pp']:+.2f}"] for i,d in enumerate(DS)])
    primary=mdtable(['数据集','均值差，百分点','95%未校正配对区间','未校正p','Holm校正p','胜/平/负'],[
        [NAMES[r['dataset']],f"{r['mean_delta_pp']:+.3f}",f"[{r['ci95_unadjusted_low_pp']:+.3f}, {r['ci95_unadjusted_high_pp']:+.3f}]",f"{r['p_two_sided']:.4f}",f"{r['p_holm_three_datasets']:.4f}",f"{r['wins']}/{r['ties']}/{r['losses']}"] for r in DATA['formal_primary']])
    support=[]
    for d in DS:
        row=[NAMES[d]]
        for ref in ['B1','B3']:
            c=FORMAL['supporting_descriptive_comparisons'][d+':B2-'+ref]
            row.extend([f"{c['mean_delta_pp']:+.3f}",f"[{c['ci95_unadjusted_pp'][0]:+.3f}, {c['ci95_unadjusted_pp'][1]:+.3f}]"])
        support.append(row)
    support=mdtable(['数据集','B2−B1，百分点','95%未校正配对区间','B2−B3，百分点','95%未校正配对区间'],support)
    devmap={'B0':'v2_dev36','B2':'v2_dev36','D':'v2_dev36','S':'v2_dev36','R':'R9','DS':'DS9','C':'C9'}
    dev=mdtable(['数据集']+list(devmap),[[NAMES[d]]+[pm(group(b,d,m)) for m,b in devmap.items()] for d in DS])
    comps=[('D','B2'),('S','B2'),('S','R'),('R','B2'),('DS','S'),('DS','B2'),('C','S'),('C','B2')]
    deltarows=[[NAMES[d]]+[f"{diff(d,m,r)['mean_delta_pp']:+.3f}" for m,r in comps] for d in DS]
    deltarows.append(['三图等权']+[f"{st.mean(diff(d,m,r)['mean_delta_pp'] for d in DS):+.4f}" for m,r in comps])
    devdelta=mdtable(['数据集']+[m+'−'+r for m,r in comps],deltarows)

    def singletable(batch,methods):
        return mdtable(['方法','seed0','seed1','seed2','均值±总体标准差，%'],[
            [m]+[f'{v:.1f}' for v in group(batch,'cora',m)['per_seed_percent']]+[pm(group(batch,'cora',m))] for m in methods])
    def comparetable(batch):
        return mdtable(['比较','seed0/1/2差值，百分点','均值差，百分点','胜/平/负','留一均值范围，百分点'],[
            [c['method']+'−'+c['reference'],' / '.join(f'{x:+.1f}' for x in c['differences_pp']),f"{c['mean_delta_pp']:+.3f}",
             f"{c['wins']}/{c['ties']}/{c['losses']}",f"{min(c['leave_one_seed_out_mean_pp']):+.3f}～{max(c['leave_one_seed_out_mean_pp']):+.3f}"]
            for c in DATA['development_comparisons'] if c['method_batch']==batch])
    p=singletable('P12',['S','H','P','PS']);j=singletable('J12',['S','NA','NR','NC'])
    pc=comparetable('P12');jc=comparetable('J12')
    dataset=mdtable(['数据集','节点','含自环边数','特征维度','类别','训练/验证/测试节点'],[
        ['Cora',2708,13264,1433,7,'140 / 500 / 1000'],['Citeseer',3327,12431,3703,6,'120 / 500 / 1000'],['PubMed',19717,108365,500,3,'60 / 500 / 1000']])
    config=mdtable(['数据集','预训练/最终探测轮数','隐藏维度/头数','输入掩码率','预训练/探测学习率'],[
        ['Cora','2000 / 300','1024 / 8','0.5','0.001 / 0.025'],['Citeseer','500 / 500','1024 / 4','0.5','0.0005 / 0.025'],['PubMed','2000 / 500','512 / 2','0.9','0.005 / 0.025']])
    resources=[]
    for d in DS:
        times=[];mem=[]
        for m in ['B0','B2']:
            times.append(FORMAL['groups'][d+':'+m]['pretrain_including_intermediate_probes']['wall_seconds'])
            mem.append(max(r['resources']['pretrain_including_intermediate_probes']['pytorch_peak_allocated_bytes'] for r in FORMAL['runs'] if r['dataset']==d and r['method']==m)/1024**2)
        resources.append([NAMES[d],f'{times[0]:.2f}',f'{times[1]:.2f}',f'{(times[1]/times[0]-1)*100:+.2f}%',f'{mem[0]:.2f} / {mem[1]:.2f}'])
    resource=mdtable(['数据集','B0平均预训练秒','B2平均预训练秒','观察相对差','B0/B2最大分配峰值MiB'],resources)
    context=dict(DATASET_TABLE=dataset,CONFIG_TABLE=config,FORMAL_TABLE=formal,PRIMARY_TABLE=primary,SUPPORT_TABLE=support,
                 RESOURCE_TABLE=resource,DEV_TABLE=dev,DEV_DELTA_TABLE=devdelta,P_TABLE=p,P_COMPARE_TABLE=pc,J_TABLE=j,J_COMPARE_TABLE=jc)
    template=(ROOT/'tools/report_template.md').read_text('utf-8')
    for key,value in context.items():template=template.replace('{{'+key+'}}',value)
    assert '{{' not in template
    write('课程报告初稿.md',template)
    write('02_统一结果总表.md',f'''# 统一结果总表

更新日期：2026-11-06（北京时间）。本文件由同一份冻结JSON生成，来源与复算规则见`tables/unified_results.json`、`sources/source_manifest.json`及`tools/rebuild_results.py`。

## 正式测试：120次

主指标`val_selected_test_acc`，三图×B0/B1/B2/B3×种子10～19。准确率%，均值±总体标准差ddof=0，n=10；差值单位百分点。

{formal}

{primary}

双侧配对t，df=9；区间使用差值样本标准差ddof=1且未校正。三个主要p值统一Holm校正，只有Cora通过0.05。三图等权+0.237个百分点只作描述。历史60次基线不替换同批B0。

## 三图开发验证：原36次及R/DS/C各9次

指标`best_val_acc`，种子0/1/2，每组n=3。准确率%，均值±总体标准差ddof=0。B0/B2/D/S来自原v2；R/DS/C为后续批次，参照不重复计为新增训练。

{dev}

配对差值与来源批次：

{devdelta}

原36、R9、DS9、C9均有既有独立产物核验PASS。本轮核对留存指标并复算；未重新审计全部数组、源码或权重。三图开发表不能与正式测试表或论文测试值直接相减。

## Cora P12：本批四组，验证n=3

{p}

{pc}

证据状态：服务器独立审计脚本回传PASS，完整报告及原始产物未在本地重新读取。P停止扩张。768项源码核对不是768字节。

## Cora J12：本批四组，验证n=3

{j}

{jc}

证据状态：保存摘要已回传复算，原始产物独立核验待完成。NA/NR暂不扩大，NC保留为负向对照。NA−NC不能替换NA−S；NR−S一胜两负，不称稳定提升。

P/J分别保留本批S，不借用早期S。P/J的S虽然逐种子验证值相同，也不能据此推断配置、轨迹或原始产物逐位相同。

## 机器表索引

| 文件 | 内容 |
| --- | --- |
| `tables/formal_test_runs_120.csv` | 120条正式逐运行测试值及原始成员路径 |
| `tables/formal_test_summary.csv` | 正式12组均值、总体标准差、种子和指标 |
| `tables/formal_B2_minus_B0_per_seed.csv` | 三图共30条逐种子配对差值 |
| `tables/formal_B2_minus_B0_statistics.csv` | 三项主要比较的区间、原始p与Holm p |
| `tables/development_validation_runs_87.csv` | 87条开发逐运行值，保留批次及证据状态 |
| `tables/development_3graphs_summary.csv` | 三图21组开发汇总 |
| `tables/development_P12_J12_summary.csv` | 分批保存P/J共8组汇总 |
| `tables/development_paired_comparisons.csv` | 52项分批配对比较及留一种子敏感性 |
| `tables/mechanism_S_R.csv` | 已核验S/R机制图数据 |
| `tables/run_ledger.csv` | 267次主要完整训练账本 |

CSV使用UTF-8 BOM。`accuracy_percent`为百分比，`*_pp`为百分点；差值有符号。标准差是总体标准差，不是标准误或置信区间。所有开发比较为描述性，不作显著性或等效声明。
''')
    write('01_范围与证据清单.md',f'''# 收尾范围与证据清单

冻结登记：2026-11-06（北京时间）。依据用户指定《GraphMAE2后续收尾计划》。这是收尾登记，不回溯声称实验前预注册。

**主方案固定B2，停止新增小图方法和参数搜索。**保留当前J版本及历史源码，不回退服务器或覆盖旧结果。

| 项目 | 固定口径 |
| --- | --- |
| 研究对象 | GraphMAE2三个小图，输入掩码节点选择 |
| 正式证据 | 同批B0/B1/B2/B3、三图、种子10～19，共120次 |
| 主指标/主比较 | 最终编码器的`val_selected_test_acc`；每图B2−同批B0 |
| 汇总与推断 | 均值±总体标准差ddof=0；配对t区间用差值样本标准差ddof=1；三项主要p值Holm校正 |
| 开发证据 | `best_val_acc`，种子0/1/2；各批次参照保留身份 |
| 不扩大内容 | EMA、课程时间、配对阈值、随机计划种子、新损失/教师/骨干及小图正式扩种 |
| 大图 | 独立可选扩展；L0/L1及完整训练均未执行、预算未选，不计入267 |

| 批次 | 完整训练数 | 当前证据等级 |
| --- | --- | --- |
| 历史基线 | 60 | 历史摘要和原日志位置留存；本轮未逐种子复算 |
| 正式v1 | 120 | 既有独立产物核验PASS；本轮原始指标复核 |
| 原v2 | 36 | 同上 |
| R / DS / C | 9 / 9 / 9 | 固定Git提交下既有独立产物核验PASS；本轮原始指标复核 |
| P12 | 12 | 服务器独立审计回传PASS；本轮摘要复算 |
| J12 | 12 | 摘要复算；原始产物独立核验待完成 |

主结论：Cora +0.35、Citeseer −0.10、PubMed +0.46个百分点，只有Cora通过Holm校正。S−B2等权仅+0.0667，DS/C/P无额外整体开发收益；J的NA−S为+0.133、NA−NR为−0.067。保留所有负结果，不将较弱辅助对照造成的差距写成相对主基准收益。

主要完整账本60+120+36+9+9+9+12+12=267；筛选/回归/冒烟/100轮诊断另计。267不是独立样本数。

已完成A/B：本页范围冻结、分批结果总表、CSV/JSON、来源哈希及数字复核。D已形成初稿和两张图。C按《有限核对与待补项》保留缺项；E的当前交付自洽检查已完成，最终课程格式、最新实际提交与外置资产保存核实仍待补齐。
''')
    print('Generated report and A/B scope/result documents from frozen tables.')


if __name__=='__main__':main()
