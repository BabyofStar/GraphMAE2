"""Verify delivery content, links, chart assets and separate metric populations."""
from pathlib import Path
import csv
import hashlib
import json
import math
import re
import struct
import sys
import xml.etree.ElementTree as ET

sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent.parent


def load(path):return json.loads((ROOT/path).read_text('utf-8-sig'))
def csvrows(path):
    with (ROOT/path).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))


def main():
    data=load('tables/unified_results.json')
    checks=load('validation_checks.json')
    assert checks['status']=='PASS'
    expected={
        'formal_test_runs_120.csv':120,'formal_test_summary.csv':12,
        'formal_B2_minus_B0_per_seed.csv':30,'formal_B2_minus_B0_statistics.csv':3,
        'development_validation_runs_87.csv':87,'development_3graphs_summary.csv':21,
        'development_P12_J12_summary.csv':8,'development_paired_comparisons.csv':52,
        'mechanism_S_R.csv':9,'run_ledger.csv':8,
    }
    for name,n in expected.items():assert len(csvrows('tables/'+name))==n,(name,n)
    assert {r['metric'] for r in csvrows('tables/formal_test_runs_120.csv')}=={'val_selected_test_acc'}
    assert {r['metric'] for r in csvrows('tables/development_validation_runs_87.csv')}=={'best_val_acc'}
    assert sum(int(r['full_pretrain_runs']) for r in csvrows('tables/run_ledger.csv'))==267

    report=(ROOT/'课程报告初稿.md').read_text('utf-8')
    unified=(ROOT/'02_统一结果总表.md').read_text('utf-8')
    readme=(ROOT/'README.md').read_text('utf-8')
    # Every reported group summary must match the machine data at displayed precision.
    for group in data['formal_groups']:
        value=f"{group['mean_percent']:.2f}±{group['population_sd_percent']:.2f}"
        assert value in report and value in unified,value
        if group['method'] in ['B0','B2']:assert value in readme,value
    for group in data['development_groups']:
        value=f"{group['mean_percent']:.3f}±{group['population_sd_percent']:.3f}"
        assert value in report and value in unified,value
    for p in data['formal_primary']:
        assert f"{p['p_holm_three_datasets']:.4f}" in report
        assert f"{p['p_holm_three_datasets']:.4f}" in readme
    assert '只有Cora通过' in report and '只有Cora通过' in readme
    assert '0.0466' in report and '0.0932' in report
    assert '原始产物独立核验待完成' in report
    assert '完整审计报告及原始产物尚未在本地重新读取' in report
    assert 'L0资源与数据预检、L1工程/测量和完整训练均未执行' in report

    relative_links=0
    docs=list(ROOT.glob('*.md'))+[ROOT/'tools/复算说明.md']
    for doc in docs:
        text=doc.read_text('utf-8')
        assert '\ufffd' not in text and '{{' not in text,doc
        for link in re.findall(r'!?\[[^\]]*\]\(([^)]+)\)',text):
            if link.startswith(('https://','http://','#')):continue
            target=(doc.parent/link.split('#',1)[0]).resolve()
            assert target.is_relative_to(ROOT.resolve()) and target.exists(),(doc.name,link)
            relative_links+=1
    assets=[]
    for name in ['formal_B2_minus_B0','mechanism_S_R']:
        svg=ROOT/'figures'/f'{name}.svg'
        ET.fromstring(svg.read_text('utf-8'))
        data_bytes=(ROOT/'figures'/f'{name}.png').read_bytes()
        assert data_bytes[:8]==b'\x89PNG\r\n\x1a\n'
        w,h=struct.unpack('>II',data_bytes[16:24]);assert w>=2400 and h>=1200
        assets.append(dict(name=name,width=w,height=h))
    html=(ROOT/'课程报告初稿.html').read_text('utf-8')
    assert html.count('src="data:image/png;base64,')==2
    assert '<script' not in html and '{{' not in html
    assert not re.search(r'<(?:img|link|iframe)[^>]+(?:src|href)="https?://',html)
    provenance=load('sources/source_manifest.json')
    for entry in provenance['files']:
        assert hashlib.sha256((ROOT/entry['snapshot']).read_bytes()).hexdigest()==entry['sha256']
    resources=load('sources/resource_recheck.json')
    assert resources['status']=='PASS' and resources['raw_resources_equal_saved_analysis']==60
    formal_source=load('sources/formal120/analysis_results.json')
    for key,value in resources['maxima_MiB'].items():
        ds,method=key.split(':')
        actual=max(r['resources']['pretrain_including_intermediate_probes']['pytorch_peak_allocated_bytes'] for r in formal_source['runs'] if r['dataset']==ds and r['method']==method)/1024**2
        assert math.isclose(actual,value,abs_tol=1e-12)

    result=dict(status='PASS',date='2026-11-06 Asia/Shanghai',csv_rows=expected,
        report_group_cells_match_machine_data=True,formal_and_development_metrics_separate=True,
        relative_markdown_links_verified=relative_links,source_snapshot_hashes_unchanged=len(provenance['files']),
        raw_resource_records_crosschecked=60,resource_table_matches_raw_maxima=True,
        figure_assets=assets,self_contained_html=True,
        evidence_limits_preserved=['P12 server audit return only','J12 raw artifact audit pending',
                                   'latest GitHub commit inventory not verified','large graph extension not run'],
        visual_review='Two figures plus report opening, formal-results section and development section visually reviewed; browser layout at 1440px has no horizontal page overflow and no external requests.',
        scope='Local delivery consistency only. Does not establish raw J12 audit, current remote sync or server asset backup.')
    (ROOT/'document_checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':main()
